"""
Client history log — every meaningful action, timestamped and tied
to who it involved and who performed it. Read-heavy by design: this
is the audit-friendly record a business (or a regulator) would want
to review, so there's deliberately no update/delete endpoint —
history doesn't get edited after the fact.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from app.core.deps import get_current_user
from app.db.session import get_session
from app.models.client import Client
from app.models.transaction import Transaction, TransactionCreate, TransactionRead
from app.models.user import User

router = APIRouter(
    prefix="/transactions", tags=["transactions"], dependencies=[Depends(get_current_user)]
)


@router.get("/", response_model=list[TransactionRead])
async def list_transactions(session: AsyncSession = Depends(get_session)):
    result = await session.exec(select(Transaction).order_by(Transaction.created_at.desc()))
    return result.all()


@router.get("/client/{client_id}", response_model=list[TransactionRead])
async def get_client_history(client_id: int, session: AsyncSession = Depends(get_session)):
    """The full history for one client — the 'client history table' view."""
    client = await session.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail="Client not found")

    result = await session.exec(
        select(Transaction)
        .where(Transaction.client_id == client_id)
        .order_by(Transaction.created_at.desc())
    )
    return result.all()


@router.post("/", response_model=TransactionRead, status_code=201)
async def create_transaction(
    tx_in: TransactionCreate,
    session: AsyncSession = Depends(get_session),
    current_user: User = Depends(get_current_user),
):
    client = await session.get(Client, tx_in.client_id)
    if not client:
        raise HTTPException(status_code=404, detail="Client not found")

    transaction = Transaction.model_validate(tx_in, update={"created_by": current_user.id})
    session.add(transaction)
    await session.commit()
    await session.refresh(transaction)
    return transaction
