"""
Archive of deactivated accounts — clients or staff. The original
row still exists (soft-deleted via is_active=False, never hard-deleted),
this table just makes "who got removed, when, by whom" a first-class
queryable record instead of something you'd have to dig for in the
audit log. Reinstatement = flip is_active back True on the original
row, then set restored_at here.

No FK to a specific client/user row here on purpose — a single column
can't cleanly reference two different tables in Postgres, and the
entity might itself be soft-deleted (not gone), so entity_id is just
a plain indexed reference, not an enforced foreign key.
"""

from datetime import datetime
from enum import Enum

from sqlmodel import Field, SQLModel


class EntityType(str, Enum):
    client = "client"
    user = "user"


class DeletedAccount(SQLModel, table=True):
    __tablename__ = "deleted_account"

    id: int | None = Field(default=None, primary_key=True)
    entity_type: EntityType = Field(index=True)
    entity_id: int = Field(index=True)
    name: str | None = Field(default=None, max_length=200)
    email: str = Field(max_length=255)
    deleted_by: int = Field(foreign_key="user.id", index=True)
    deleted_at: datetime = Field(default_factory=datetime.utcnow, index=True)
    restored_at: datetime | None = Field(default=None)
