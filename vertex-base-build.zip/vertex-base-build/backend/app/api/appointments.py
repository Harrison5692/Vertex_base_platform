"""
Appointment router — service scheduling and catering events.
Same tiered-access pattern as accounts.py/transactions.py: a tier-1
account sees only their own appointments, tier-2+ (staff) can see
and manage everyone's.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from app.core.deps import get_current_account, require_min_tier
from app.db.session import get_session
from app.models.account import Account
from app.models.appointment import (
    Appointment,
    AppointmentCreate,
    AppointmentRead,
    AppointmentUpdate,
)

router = APIRouter(
    prefix="/appointments", tags=["appointments"], dependencies=[Depends(get_current_account)]
)


@router.get("/", response_model=list[AppointmentRead], dependencies=[Depends(require_min_tier(2))])
async def list_appointments(session: AsyncSession = Depends(get_session)):
    """Staff and above only — every appointment, across every account."""
    result = await session.exec(select(Appointment).order_by(Appointment.scheduled_at))
    return result.all()


@router.get("/account/{account_id}", response_model=list[AppointmentRead])
async def get_account_appointments(
    account_id: int,
    session: AsyncSession = Depends(get_session),
    current: Account = Depends(get_current_account),
):
    """A single account's appointments — self, or staff and above."""
    if current.tier < 2 and current.id != account_id:
        raise HTTPException(status_code=403, detail="Can only view your own appointments")

    result = await session.exec(
        select(Appointment)
        .where(Appointment.account_id == account_id)
        .order_by(Appointment.scheduled_at)
    )
    return result.all()


@router.post("/", response_model=AppointmentRead, status_code=201)
async def create_appointment(
    appt_in: AppointmentCreate,
    session: AsyncSession = Depends(get_session),
    current: Account = Depends(get_current_account),
):
    account = await session.get(Account, appt_in.account_id)
    if not account:
        raise HTTPException(status_code=404, detail="Account not found")

    appointment = Appointment.model_validate(appt_in, update={"created_by": current.id})
    session.add(appointment)
    await session.commit()
    await session.refresh(appointment)
    return appointment


@router.patch("/{appointment_id}", response_model=AppointmentRead)
async def update_appointment(
    appointment_id: int,
    appt_in: AppointmentUpdate,
    session: AsyncSession = Depends(get_session),
    current: Account = Depends(get_current_account),
):
    """Self, or staff and above — a client can reschedule/cancel their
    own appointment, staff can manage any."""
    appointment = await session.get(Appointment, appointment_id)
    if not appointment:
        raise HTTPException(status_code=404, detail="Appointment not found")
    if current.tier < 2 and current.id != appointment.account_id:
        raise HTTPException(status_code=403, detail="Can only update your own appointments")

    for field, value in appt_in.model_dump(exclude_unset=True).items():
        setattr(appointment, field, value)
    session.add(appointment)
    await session.commit()
    await session.refresh(appointment)
    return appointment
