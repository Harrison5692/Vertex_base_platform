"""
Appointment — the entity service-scheduling and catering businesses
need that POS/retail doesn't. A pressure-washing job, a massage
booking, a catering event date — all the same shape: an account,
optionally an item (which service/package), a scheduled time, and
a status tracking whether it happened.

Deliberately not used by a pure POS/retail deployment — the table
just sits empty for them, which costs nothing. Whether a given
deployment surfaces this in its UI at all is a client.config.json
question (see the "features" convention in CUSTOMIZING.md), not a
schema question — the table exists in every deployment either way.
"""

from datetime import datetime
from enum import Enum

from sqlmodel import Field, SQLModel


class AppointmentStatus(str, Enum):
    scheduled = "scheduled"
    completed = "completed"
    cancelled = "cancelled"
    no_show = "no_show"


class AppointmentBase(SQLModel):
    account_id: int = Field(foreign_key="account.id", index=True)
    item_id: int | None = Field(default=None, foreign_key="item.id", index=True)
    scheduled_at: datetime = Field(index=True)
    duration_minutes: int | None = Field(default=None)
    status: AppointmentStatus = Field(default=AppointmentStatus.scheduled, index=True)
    notes: str | None = None


class Appointment(AppointmentBase, table=True):
    id: int | None = Field(default=None, primary_key=True)
    created_by: int = Field(foreign_key="account.id", index=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)


class AppointmentCreate(AppointmentBase):
    pass


class AppointmentRead(AppointmentBase):
    id: int
    created_by: int
    created_at: datetime


class AppointmentUpdate(SQLModel):
    scheduled_at: datetime | None = None
    duration_minutes: int | None = None
    status: AppointmentStatus | None = None
    notes: str | None = None
