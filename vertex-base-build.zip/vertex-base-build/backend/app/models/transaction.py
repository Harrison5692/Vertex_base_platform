"""
History log — every meaningful business action, tied to the account
it involved and the account that performed it.

appointment_id links a transaction back to the specific appointment
it resulted from (a completed service, a catering event) — nullable,
since a POS sale has no appointment at all. This is what actually
connects the operational record (Appointment: was it scheduled, did
it happen) to the financial record (Transaction: what was charged),
rather than leaving them as two disconnected tables a person has to
guess between by matching timestamps.

deposit_amount/balance_due are optional, added for staged-payment
cases like catering (deposit now, balance at the event) — a simple
POS sale just leaves both null.

Foreign keys are explicitly indexed here: Postgres does NOT auto-index
FK columns, only primary keys and unique constraints, so without this
every join/filter on account_id or created_at would be a full table
scan once there's real data volume.
"""

from datetime import datetime
from enum import Enum

from sqlmodel import Field, SQLModel


class TransactionType(str, Enum):
    created = "created"
    updated = "updated"
    completed = "completed"
    cancelled = "cancelled"


class TransactionBase(SQLModel):
    account_id: int = Field(foreign_key="account.id", index=True)
    item_id: int | None = Field(default=None, foreign_key="item.id", index=True)
    appointment_id: int | None = Field(default=None, foreign_key="appointment.id", index=True)
    type: TransactionType
    notes: str | None = None

    # Staged payments — catering deposits, service booking deposits, etc.
    # Both null for a simple one-shot POS/retail sale.
    deposit_amount: float | None = Field(default=None)
    balance_due: float | None = Field(default=None)


class Transaction(TransactionBase, table=True):
    id: int | None = Field(default=None, primary_key=True)
    created_by: int = Field(foreign_key="account.id", index=True)
    created_at: datetime = Field(default_factory=datetime.utcnow, index=True)


class TransactionCreate(TransactionBase):
    pass


class TransactionRead(TransactionBase):
    id: int
    created_by: int
    created_at: datetime
